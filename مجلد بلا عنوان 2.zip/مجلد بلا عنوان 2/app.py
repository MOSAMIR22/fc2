from flask import Flask, jsonify, render_template_string
from flask_cors import CORS
import json
import os
import requests
from bs4 import BeautifulSoup
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler

app = Flask(__name__)
CORS(app)

# ========== CONFIG ==========
RENDER_URL = os.environ.get('RENDER_EXTERNAL_URL', 'http://localhost:5000')

# ========== HTML TEMPLATE ==========
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عروضك - كل عروض المحمول</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .header { background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); padding: 30px 20px; text-align: center; color: white; }
        .header h1 { font-size: 2.5em; margin-bottom: 10px; }
        .container { max-width: 1200px; margin: 0 auto; padding: 30px 20px; }
        .filters { display: flex; gap: 15px; margin-bottom: 30px; flex-wrap: wrap; justify-content: center; }
        .filters select, .filters button { padding: 12px 25px; border: none; border-radius: 25px; font-size: 16px; cursor: pointer; }
        .filters select { background: white; color: #333; }
        .filters button { background: #ff6b6b; color: white; }
        .offers-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 25px; }
        .offer-card { background: white; border-radius: 20px; padding: 25px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); transition: transform 0.3s; position: relative; }
        .offer-card:hover { transform: translateY(-10px); }
        .company-badge { position: absolute; top: 15px; left: 15px; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: bold; color: white; }
        .vodafone { background: #e60000; } .orange { background: #ff6600; }
        .etisalat { background: #009900; } .we { background: #6600cc; }
        .offer-type { display: inline-block; padding: 5px 15px; background: #f0f0f0; border-radius: 15px; font-size: 12px; color: #666; margin-bottom: 15px; }
        .offer-name { font-size: 1.5em; color: #333; margin-bottom: 10px; }
        .offer-value { color: #667eea; font-size: 1.1em; margin-bottom: 15px; line-height: 1.6; }
        .offer-price { font-size: 2em; color: #ff6b6b; font-weight: bold; margin-bottom: 15px; }
        .offer-price span { font-size: 0.5em; color: #999; }
        .code-box { background: #f8f9fa; padding: 15px; border-radius: 10px; text-align: center; margin-bottom: 15px; border: 2px dashed #667eea; }
        .code-box strong { display: block; color: #667eea; font-size: 1.3em; margin-bottom: 5px; }
        .valid-until { color: #999; font-size: 0.9em; margin-bottom: 15px; }
        .btn-action { width: 100%; padding: 15px; border: none; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; transition: all 0.3s; }
        .btn-copy { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; margin-bottom: 10px; }
        .btn-link { background: #f0f0f0; color: #333; }
        .btn-action:hover { opacity: 0.9; transform: scale(1.02); }
        .notification { position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%); background: #333; color: white; padding: 15px 30px; border-radius: 30px; display: none; z-index: 1000; }
        .loading { text-align: center; color: white; font-size: 1.5em; padding: 50px; }
        .stats { display: flex; justify-content: center; gap: 40px; margin: 20px 0; color: white; flex-wrap: wrap; }
        .stat { text-align: center; }
        .stat-number { font-size: 2.5em; font-weight: bold; }
        .stat-label { opacity: 0.8; }
        .last-update { color: rgba(255,255,255,0.8); margin-top: 10px; font-size: 0.9em; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🎁 عروضك</h1>
        <p>كل عروض شركات المحمول في مكان واحد - مجاني 100%</p>
        <div class="stats">
            <div class="stat"><div class="stat-number" id="offersCount">0</div><div class="stat-label">عرض متاح</div></div>
            <div class="stat"><div class="stat-number">4</div><div class="stat-label">شركة</div></div>
            <div class="stat"><div class="stat-number">مجاني</div><div class="stat-label">للأبد</div></div>
        </div>
        <div class="last-update" id="lastUpdate">آخر تحديث: --</div>
    </div>
    
    <div class="container">
        <div class="filters">
            <select id="companyFilter" onchange="filterOffers()">
                <option value="">كل الشركات</option>
                <option value="Vodafone">Vodafone</option>
                <option value="Orange">Orange</option>
                <option value="Etisalat">Etisalat</option>
                <option value="We">We</option>
            </select>
            <select id="typeFilter" onchange="filterOffers()">
                <option value="">كل الأنواع</option>
                <option value="فكة">فكة</option>
                <option value="مارد">مارد</option>
                <option value="باقة نت">باقة نت</option>
            </select>
            <button onclick="refreshOffers()">🔄 تحديث من الشركات</button>
        </div>
        
        <div id="offersContainer" class="offers-grid">
            <div class="loading">⏳ جاري تحميل العروض...</div>
        </div>
    </div>
    
    <div class="notification" id="notification"></div>

    <script>
        let allOffers = [];
        
        async function loadOffers() {
            try {
                const response = await fetch('/api/offers');
                const data = await response.json();
                allOffers = data.offers || [];
                displayOffers(allOffers);
                document.getElementById('offersCount').textContent = allOffers.length;
                document.getElementById('lastUpdate').textContent = 'آخر تحديث: ' + new Date().toLocaleString('ar-EG');
            } catch (error) {
                document.getElementById('offersContainer').innerHTML = '<div class="loading">❌ حدث خطأ في تحميل العروض</div>';
            }
        }
        
        function displayOffers(offers) {
            const container = document.getElementById('offersContainer');
            if (offers.length === 0) {
                container.innerHTML = '<div class="loading">لا توجد عروض مطابقة</div>';
                return;
            }
            
            container.innerHTML = offers.map(offer => `
                <div class="offer-card">
                    <div class="company-badge333; margin-bottom: 10px; }
        .offer-value { color: #667eea; font-size: 1.1em; margin-bottom: 15px; line-height: 1.6; }
        .offer-price { font-size: 2em; color: #ff6b6b; font-weight: bold; margin-bottom: 15px; }
        .offer-price span { font-size: 0.5em; color: #999; }
        .code-box { background: #f8f9fa; padding: 15px; border-radius: 10px; text-align: center; margin-bottom: 15px; border: 2px dashed #667eea; }
        .code-box strong { display: block; color: #667eea; font-size: 1.3em; margin-bottom: 5px; }
        .valid-until { color: #999; font-size: 0.9em; margin-bottom: 15px; }
        .btn-action { width: 100%; padding: 15px; border: none; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; transition: all 0.3s; }
        .btn-copy { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; margin-bottom: 10px; }
        .btn-link { background: #f0f0f0; color: #333; }
        .btn-action:hover { opacity: 0.9; transform: scale(1.02); }
        .notification { position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%); background: #333; color: white; padding: 15px 30px; border-radius: 30px; display: none; z-index: 1000; }
        .loading { text-align: center; color: white; font-size: 1.5em; padding: 50px; }
        .stats { display: flex; justify-content: center; gap: 40px; margin: 20px 0; color: white; flex-wrap: wrap; }
        .stat { text-align: center; }
        .stat-number { font-size: 2.5em; font-weight: bold; }
        .stat-label { opacity: 0.8; }
        .last-update { color: rgba(255,255,255,0.8); margin-top: 10px; font-size: 0.9em; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🎁 عروضك</h1>
        <p>كل عروض شركات المحمول في مكان واحد - مجاني 100%</p>
        <div class="stats">
            <div class="stat"><div class="stat-number" id="offersCount">0</div><div class="stat-label">عرض متاح</div></div>
            <div class="stat"><div class="stat-number">4</div><div class="stat-label">شركة</div></div>
            <div class="stat"><div class="stat-number">مجاني</div><div class="stat-label">للأبد</div></div>
        </div>
        <div class="last-update" id="lastUpdate">آخر تحديث: --</div>
    </div>
    
    <div class="container">
        <div class="filters">
            <select id="companyFilter" onchange="filterOffers()">
                <option value="">كل الشركات</option>
                <option value="Vodafone">Vodafone</option>
                <option value="Orange">Orange</option>
                <option value="Etisalat">Etisalat</option>
                <option value="We">We</option>
            </select>
            <select id="typeFilter" onchange="filterOffers()">
                <option value="">كل الأنواع</option>
                <option value="فكة">فكة</option>
                <option value="مارد">مارد</option>
                <option value="باقة نت">باقة نت</option>
            </select>
            <button onclick="refreshOffers()">🔄 تحديث من الشركات</button>
        </div>
        
        <div id="offersContainer" class="offers-grid">
            <div class="loading">⏳ جاري تحميل العروض...</div>
        </div>
    </div>
    
    <div class="notification" id="notification"></div>

    <script>
        let allOffers = [];
        
        async function loadOffers() {
            try {
                const response = await fetch('/api/offers');
                const data = await response.json();
                allOffers = data.offers || [];
                displayOffers(allOffers);
                document.getElementById('offersCount').textContent = allOffers.length;
                document.getElementById('lastUpdate').textContent = 'آخر تحديث: ' + new Date().toLocaleString('ar-EG');
            } catch (error) {
                document.getElementById('offersContainer').innerHTML = '<div class="loading">❌ حدث خطأ في تحميل العروض</div>';
            }
        }
        
        function displayOffers(offers) {
            const container = document.getElementById('offersContainer');
            if (offers.length === 0) {
                container.innerHTML = '<div class="loading">لا توجد عروض مطابقة</div>';
                return;
            }
            
            container.innerHTML = offers.map(offer => `
                <div class="offer-card">
                    <div class="company-badge ${offer.company.toLowerCase()}">${offer.company}</div>
                    <span class="offer-type">${offer.type}</span>
                    <h3 class="offer-name">${offer.name}</h3>
                    <p class="offer-value">${offer.value}</p>
                    <div class="offer-price">${offer.price} <span>جنيه</span></div>
                    <div class="code-box">
                        <strong>${offer.code}</strong>
                        <small>كود الاشتراك</small>
                    </div>
                    <p class="valid-until">⏰ ساري حتى: ${offer.valid_until}</p>
                    <button class="btn-action btn-copy" onclick="copyCode('${offer.code}')">📋 نسخ الكود</button>
                    <button class="btn-action btn-link" onclick="window.open('${offer.link}', '_blank')">🌐 زيارة الموقع</button>
                </div>
            `).join('');
        }
        
        function filterOffers() {
            const company = document.getElementById('companyFilter').value;
            const type = document.getElementById('typeFilter').value;
            let filtered = allOffers;
            if (company) filtered = filtered.filter(o => o.company === company);
            if (type) filtered = filtered.filter(o => o.type === type);
            displayOffers(filtered);
        }
        
        function copyCode(code) {
            navigator.clipboard.writeText(code).then(() => {
                showNotification('✅ تم نسخ الكود: ' + code);
            });
        }
        
        function showNotification(msg) {
            const notif = document.getElementById('notification');
            notif.textContent = msg;
            notif.style.display = 'block';
            setTimeout(() => notif.style.display = 'none', 3000);
        }
        
        async function refreshOffers() {
            const btn = document.querySelector('button[onclick="refreshOffers()"]');
            btn.disabled = true;
            btn.textContent = '⏳ جاري التحديث...';
            document.getElementById('offersContainer').innerHTML = '<div class="loading">⏳ جاري جلب العروض من الشركات...</div>';
            
            try {
                const response = await fetch('/api/scrape', { method: 'POST' });
                const data = await response.json();
                showNotification(data.success ? '✅ ' + data.message : '❌ فشل التحديث');
                loadOffers();
            } catch (error) {
                showNotification('❌ حدث خطأ');
                loadOffers();
            }
            
            btn.disabled = false;
            btn.textContent = '🔄 تحديث من الشركات';
        }
        
        loadOffers();
    </script>
</body>
</html>
'''

# ========== SCRAPER ==========
class OffersScraper:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0'
        }
        self.offers = []
    
    def scrape_vodafone(self):
        try:
            # محاكاة - في الحقيقة هتحلل الموقع الفعلي
            self.offers.extend([
                {"company": "Vodafone", "type": "فكة", "name": "Fakka 10", "price": 10, 
                 "value": "10 جنيه + 100 ميجا", "code": "*858*10#", "valid_until": "2026-04-30",
                 "link": "https://vodafone.com.eg"}
            ])
        except: pass
    
    def scrape_orange(self):
        try:
            self.offers.extend([
                {"company": "Orange", "type": "فكة", "name": "Fakka 15", "price": 15,
                 "value": "15 جنيه + 200 ميجا", "code": "*102*15#", "valid_until": "2026-04-30",
                 "link": "https://orange.eg"}
            ])
        except: pass
    
    def scrape_all(self):
        self.offers = []
        self.scrape_vodafone()
        self.scrape_orange()
        # ... باقي الشركات
        
        # حفظ في ملف مؤقت
        with open('offers.json', 'w', encoding='utf-8') as f:
            json.dump(self.offers, f, ensure_ascii=False)
        
        return self.offers

# ========== ROUTES ==========
@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/offers')
def get_offers():
    try:
        if os.path.exists('offers.json'):
            with open('offers.json', 'r', encoding='utf-8') as f:
                offers = json.load(f)
        else:
            offers = []
    except:
        offers = []
    
    return jsonify({
        "success": True,
        "offers": offers,
        "count": len(offers)
    })

@app.route('/api/scrape', methods=['POST'])
def do_scrape():
    scraper = OffersScraper()
    offers = scraper.scrape_all()
    return jsonify({
        "success": True,
        "message": f"تم جلب {len(offers)} عرض",
        "count": len(offers)
    })

# ========== AUTO SCRAPE ==========
def auto_scrape():
    with app.app_context():
        scraper = OffersScraper()
        scraper.scrape_all()
        print(f"Auto-scraped at {datetime.now()}")

scheduler = BackgroundScheduler()
scheduler.add_job(auto_scrape, 'interval', hours=6)
scheduler.start()

# scrape initial
auto_scrape()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
